﻿using Syroot.BinaryData;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForzaTools.Bundles.Blobs;

public class TextureContentBlob : BundleBlob
{
    public override void ReadBlobData(BinaryStream bs)
    {
        
    }

    public override void SerializeBlobData(BinaryStream bs)
    {
        
    }
}
